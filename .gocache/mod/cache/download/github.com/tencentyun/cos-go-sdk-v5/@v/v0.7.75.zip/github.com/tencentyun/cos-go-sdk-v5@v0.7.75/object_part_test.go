package cos

import (
	"bytes"
	"context"
	"crypto/rand"
	"encoding/hex"
	"encoding/xml"
	"fmt"
	"hash/crc64"
	"io/ioutil"
	"net/http"
	"os"
	"reflect"
	"strconv"
	"strings"
	"testing"
	"time"
)

func TestObjectService_AbortMultipartUpload(t *testing.T) {
	setup()
	defer teardown()
	name := "test/hello.txt"
	uploadID := "xxxxaabcc"

	mux.HandleFunc("/test/hello.txt", func(w http.ResponseWriter, r *http.Request) {
		testMethod(t, r, http.MethodDelete)
		vs := values{
			"uploadId": uploadID,
		}
		testFormValues(t, r, vs)

		w.WriteHeader(http.StatusNoContent)
	})

	_, err := client.Object.AbortMultipartUpload(context.Background(), name, uploadID)
	if err != nil {
		t.Fatalf("Object.AbortMultipartUpload returned error: %v", err)
	}
	_, err = client.Object.AbortMultipartUpload(context.Background(), "/", uploadID)
	if err == nil || err.Error() != "empty object name" {
		t.Fatalf("Object.AbortMultipartUpload expect error: %v", err)
	}
	_, err = client.Object.AbortMultipartUpload(context.Background(), "//", uploadID)
	if err != ObjectKeySimplifyCheckErr {
		t.Fatalf("Object.AbortMultipartUpload expect error: %v", err)
	}
	opt := &AbortMultipartUploadOptions{
		XOptionHeader: &http.Header{},
	}
	opt.XOptionHeader.Add("x-cos-meta-test", "value")
	_, err = client.Object.AbortMultipartUpload(context.Background(), name, uploadID, opt)
	if err != nil {
		t.Fatalf("Object.AbortMultipartUpload returned error: %v", err)
	}
}

func TestObjectService_InitiateMultipartUpload_XMLSyntaxError(t *testing.T) {
	setup()
	defer teardown()

	opt := &InitiateMultipartUploadOptions{
		ObjectPutHeaderOptions: &ObjectPutHeaderOptions{
			ContentType: "text/html",
		},
		ACLHeaderOptions: &ACLHeaderOptions{
			XCosACL: "private",
		},
	}
	eChar, _ := DecodeURIComponent("%07") //特殊字符
	eName := fmt.Sprintf("test/hello_%v.txt", eChar)
	name := "test/hello.txt"

	mux.HandleFunc("/test/hello.txt", func(w http.ResponseWriter, r *http.Request) {
		v := new(BucketPutTaggingOptions)
		xml.NewDecoder(r.Body).Decode(v)

		testMethod(t, r, http.MethodPost)
		testHeader(t, r, "x-cos-acl", "private")
		testHeader(t, r, "Content-Type", "text/html")
		vs := values{
			"uploads": "",
		}
		testFormValues(t, r, vs)
		fmt.Fprintf(w, `<InitiateMultipartUploadResult>
	<Bucket>test-1253846586</Bucket>
	<Key>%v</Key>
	<UploadId>149795166761115ef06e259b2fceb8ff34bf7dd840883d26a0f90243562dd398efa41718db</UploadId>
</InitiateMultipartUploadResult>`, eName)
	})

	ref, _, err := client.Object.InitiateMultipartUpload(context.Background(),
		name, opt)
	if err != nil {
		t.Fatalf("Object.InitiateMultipartUpload returned error: %v", err)
	}

	want := &InitiateMultipartUploadResult{
		XMLName:  xml.Name{Local: "InitiateMultipartUploadResult"},
		Bucket:   "test-1253846586",
		Key:      eName,
		UploadID: "149795166761115ef06e259b2fceb8ff34bf7dd840883d26a0f90243562dd398efa41718db",
	}

	if !reflect.DeepEqual(ref, want) {
		t.Errorf("Object.InitiateMultipartUpload returned %+v, want %+v", ref, want)
	}
}

func TestObjectService_InitiateMultipartUpload(t *testing.T) {
	setup()
	defer teardown()

	opt := &InitiateMultipartUploadOptions{
		ObjectPutHeaderOptions: &ObjectPutHeaderOptions{
			ContentType: "text/html",
		},
		ACLHeaderOptions: &ACLHeaderOptions{
			XCosACL: "private",
		},
	}
	name := "test/hello.txt"

	mux.HandleFunc("/test/hello.txt", func(w http.ResponseWriter, r *http.Request) {
		v := new(BucketPutTaggingOptions)
		xml.NewDecoder(r.Body).Decode(v)

		testMethod(t, r, http.MethodPost)
		testHeader(t, r, "x-cos-acl", "private")
		testHeader(t, r, "Content-Type", "text/html")
		vs := values{
			"uploads": "",
		}
		testFormValues(t, r, vs)
		fmt.Fprint(w, `<InitiateMultipartUploadResult>
	<Bucket>test-1253846586</Bucket>
	<Key>test/hello.txt</Key>
	<UploadId>149795166761115ef06e259b2fceb8ff34bf7dd840883d26a0f90243562dd398efa41718db</UploadId>
</InitiateMultipartUploadResult>`)
	})

	ref, _, err := client.Object.InitiateMultipartUpload(context.Background(),
		name, opt)
	if err != nil {
		t.Fatalf("Object.InitiateMultipartUpload returned error: %v", err)
	}

	want := &InitiateMultipartUploadResult{
		XMLName:  xml.Name{Local: "InitiateMultipartUploadResult"},
		Bucket:   "test-1253846586",
		Key:      "test/hello.txt",
		UploadID: "149795166761115ef06e259b2fceb8ff34bf7dd840883d26a0f90243562dd398efa41718db",
	}

	if !reflect.DeepEqual(ref, want) {
		t.Errorf("Object.InitiateMultipartUpload returned %+v, want %+v", ref, want)
	}
}

func TestObjectService_UploadPart(t *testing.T) {
	setup()
	defer teardown()

	opt := &ObjectUploadPartOptions{}
	name := "test/hello.txt"
	uploadID := "xxxxx"
	partNumber := 1

	mux.HandleFunc("/test/hello.txt", func(w http.ResponseWriter, r *http.Request) {
		testMethod(t, r, http.MethodPut)
		vs := values{
			"uploadId":   uploadID,
			"partNumber": "1",
		}
		testFormValues(t, r, vs)

		b, _ := ioutil.ReadAll(r.Body)
		tb := crc64.MakeTable(crc64.ECMA)
		crc := crc64.Update(0, tb, b)
		v := string(b)
		want := "hello"
		if !reflect.DeepEqual(v, want) {
			t.Errorf("Object.UploadPart request body: %#v, want %#v", v, want)
		}
		w.Header().Add("x-cos-hash-crc64ecma", strconv.FormatUint(crc, 10))
	})

	r := bytes.NewReader([]byte("hello"))
	_, err := client.Object.UploadPart(context.Background(),
		name, uploadID, partNumber, r, opt)
	if err != nil {
		t.Fatalf("Object.UploadPart returned error: %v", err)
	}

}

func TestObjectService_UploadPartWithEmptyData(t *testing.T) {
	setup()
	defer teardown()

	name := "test/hello.txt"
	uploadID := "xxxxx"
	partNumber := 1

	mux.HandleFunc("/test/hello.txt", func(w http.ResponseWriter, r *http.Request) {
		testMethod(t, r, http.MethodPut)
		vs := values{
			"uploadId":   uploadID,
			"partNumber": "1",
		}
		testFormValues(t, r, vs)
		if r.Header.Get("Content-Length") != "0" {
			t.Fatalf("UploadPart Content-Length is not 0")
		}
		b, _ := ioutil.ReadAll(r.Body)
		if len(b) != 0 {
			t.Fatalf("data is not empty")
		}
	})

	_, err := client.Object.UploadPart(context.Background(),
		name, uploadID, partNumber, nil, nil)
	if err != nil {
		t.Fatalf("Object.UploadPart returned error: %v", err)
	}

	_, err = client.Object.UploadPart(context.Background(),
		name, uploadID, partNumber, http.NoBody, nil)
	if err != nil {
		t.Fatalf("Object.UploadPart returned error: %v", err)
	}

	_, err = client.Object.UploadPart(context.Background(),
		name, uploadID, partNumber, http.NoBody, &ObjectUploadPartOptions{
			ContentLength: 1,
		})
	if err == nil || err.Error() != "ContentLength must be 0 when reader is nil or http.NoBody." {
		t.Fatalf("Object.UploadPart returned error: %v", err)
	}

}

func TestObjectService_ListUploads(t *testing.T) {
	setup()
	defer teardown()

	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		testMethod(t, r, http.MethodGet)
		vs := values{
			"uploads":     "",
			"max-uploads": "1000",
		}
		testFormValues(t, r, vs)

		fmt.Fprint(w, `<ListMultipartUploadsResult>
    <Bucket>examplebucket-1250000000</Bucket>
    <Encoding-Type/>
    <KeyMarker/>
    <UploadIdMarker/>
    <MaxUploads>1000</MaxUploads>
    <Prefix/>
    <Delimiter>/</Delimiter>
    <IsTruncated>false</IsTruncated>
    <Upload>
        <Key>Object</Key>
        <UploadId>1484726657932bcb5b17f7a98a8cad9fc36a340ff204c79bd2f51e7dddf0b6d1da6220520c</UploadId>
        <Initiator>
            <ID>qcs::cam::uin/100000000001:uin/100000000001</ID>
            <DisplayName>100000000001</DisplayName>
        </Initiator>
        <Owner>
            <ID>qcs::cam::uin/100000000001:uin/100000000001</ID>
            <DisplayName>100000000001</DisplayName>
        </Owner>
        <StorageClass>Standard</StorageClass>
        <Initiated>Wed Jan 18 16:04:17 2017</Initiated>
    </Upload>
    <Upload>
        <Key>Object</Key>
        <UploadId>1484727158f2b8034e5407d18cbf28e84f754b791ecab607d25a2e52de9fee641e5f60707c</UploadId>
        <Initiator>
            <ID>qcs::cam::uin/100000000001:uin/100000000001</ID>
            <DisplayName>100000000001</DisplayName>
        </Initiator>
        <Owner>
            <ID>qcs::cam::uin/100000000001:uin/100000000001</ID>
            <DisplayName>100000000001</DisplayName>
        </Owner>
        <StorageClass>Standard</StorageClass>
        <Initiated>Wed Jan 18 16:12:38 2017</Initiated>
    </Upload>
    <Upload>
        <Key>exampleobject</Key>
        <UploadId>1484727270323ddb949d528c629235314a9ead80f0ba5d993a3d76b460e6a9cceb9633b08e</UploadId>
        <Initiator>
            <ID>qcs::cam::uin/100000000001:uin/100000000001</ID>
            <DisplayName>100000000001</DisplayName>
        </Initiator>
        <Owner>
            <ID>qcs::cam::uin/100000000001:uin/100000000001</ID>
            <DisplayName>100000000001</DisplayName>
        </Owner>
        <StorageClass>Standard</StorageClass>
        <Initiated>Wed Jan 18 16:14:30 2017</Initiated>
    </Upload>
</ListMultipartUploadsResult>`)
	})

	opt := &ObjectListUploadsOptions{
		MaxUploads: 1000,
	}
	ref, _, err := client.Object.ListUploads(context.Background(), opt)
	if err != nil {
		t.Fatalf("Object.ListParts returned error: %v", err)
	}

	want := &ObjectListUploadsResult{
		XMLName:     xml.Name{Local: "ListMultipartUploadsResult"},
		Bucket:      "examplebucket-1250000000",
		MaxUploads:  "1000",
		IsTruncated: false,
		Delimiter:   "/",
		Upload: []ListUploadsResultUpload{
			{
				Key:      "Object",
				UploadID: "1484726657932bcb5b17f7a98a8cad9fc36a340ff204c79bd2f51e7dddf0b6d1da6220520c",
				Initiator: &Initiator{
					ID:          "qcs::cam::uin/100000000001:uin/100000000001",
					DisplayName: "100000000001",
				},
				Owner: &Owner{
					ID:          "qcs::cam::uin/100000000001:uin/100000000001",
					DisplayName: "100000000001",
				},
				StorageClass: "Standard",
				Initiated:    "Wed Jan 18 16:04:17 2017",
			},
			{
				Key:      "Object",
				UploadID: "1484727158f2b8034e5407d18cbf28e84f754b791ecab607d25a2e52de9fee641e5f60707c",
				Initiator: &Initiator{
					ID:          "qcs::cam::uin/100000000001:uin/100000000001",
					DisplayName: "100000000001",
				},
				Owner: &Owner{
					ID:          "qcs::cam::uin/100000000001:uin/100000000001",
					DisplayName: "100000000001",
				},
				StorageClass: "Standard",
				Initiated:    "Wed Jan 18 16:12:38 2017",
			},
			{
				Key:      "exampleobject",
				UploadID: "1484727270323ddb949d528c629235314a9ead80f0ba5d993a3d76b460e6a9cceb9633b08e",
				Initiator: &Initiator{
					ID:          "qcs::cam::uin/100000000001:uin/100000000001",
					DisplayName: "100000000001",
				},
				Owner: &Owner{
					ID:          "qcs::cam::uin/100000000001:uin/100000000001",
					DisplayName: "100000000001",
				},
				StorageClass: "Standard",
				Initiated:    "Wed Jan 18 16:14:30 2017",
			},
		},
	}

	if !reflect.DeepEqual(ref, want) {
		t.Errorf("Object.ListUploads returned \n%+v, want \n%+v", ref, want)
	}
}

func TestObjectService_ListParts(t *testing.T) {
	setup()
	defer teardown()

	name := "test/hello.txt"
	uploadID := "149795194893578fd83aceef3a88f708f81f00e879fda5ea8a80bf15aba52746d42d512387"

	mux.HandleFunc("/test/hello.txt", func(w http.ResponseWriter, r *http.Request) {
		v := new(BucketPutTaggingOptions)
		xml.NewDecoder(r.Body).Decode(v)

		testMethod(t, r, http.MethodGet)
		vs := values{
			"uploadId": uploadID,
		}
		testFormValues(t, r, vs)

		fmt.Fprint(w, `<ListPartsResult>
	<Bucket>test-1253846586</Bucket>
	<Encoding-type/>
	<Key>test/hello.txt</Key>
	<UploadId>149795194893578fd83aceef3a88f708f81f00e879fda5ea8a80bf15aba52746d42d512387</UploadId>
	<Owner>
		<ID>1253846586</ID>
		<DisplayName>1253846586</DisplayName>
	</Owner>
	<PartNumberMarker>0</PartNumberMarker>
	<Initiator>
		<ID>qcs::cam::uin/100000760461:uin/100000760461</ID>
		<DisplayName>100000760461</DisplayName>
	</Initiator>
	<Part>
		<PartNumber>1</PartNumber>
		<LastModified>2017-06-20T09:45:49.000Z</LastModified>
		<ETag>&quot;fae3dba15f4d9b2d76cbaed5de3a08e3&quot;</ETag>
		<Size>6291456</Size>
	</Part>
	<Part>
		<PartNumber>2</PartNumber>
		<LastModified>2017-06-20T09:45:50.000Z</LastModified>
		<ETag>&quot;c81982550f2f965118d486176d9541d4&quot;</ETag>
		<Size>6391456</Size>
	</Part>
	<StorageClass>Standard</StorageClass>
	<MaxParts>1000</MaxParts>
	<IsTruncated>false</IsTruncated>
</ListPartsResult>`)
	})

	ref, _, err := client.Object.ListParts(context.Background(),
		name, uploadID, nil)
	if err != nil {
		t.Fatalf("Object.ListParts returned error: %v", err)
	}

	want := &ObjectListPartsResult{
		XMLName:  xml.Name{Local: "ListPartsResult"},
		Bucket:   "test-1253846586",
		UploadID: uploadID,
		Key:      name,
		Owner: &Owner{
			ID:          "1253846586",
			DisplayName: "1253846586",
		},
		PartNumberMarker: "0",
		Initiator: &Initiator{
			ID:          "qcs::cam::uin/100000760461:uin/100000760461",
			DisplayName: "100000760461",
		},
		Parts: []Object{
			{
				PartNumber:   1,
				LastModified: "2017-06-20T09:45:49.000Z",
				ETag:         "\"fae3dba15f4d9b2d76cbaed5de3a08e3\"",
				Size:         6291456,
			},
			{
				PartNumber:   2,
				LastModified: "2017-06-20T09:45:50.000Z",
				ETag:         "\"c81982550f2f965118d486176d9541d4\"",
				Size:         6391456,
			},
		},
		StorageClass: "Standard",
		MaxParts:     "1000",
		IsTruncated:  false,
	}

	if !reflect.DeepEqual(ref, want) {
		t.Errorf("Object.ListParts returned \n%#v, want \n%#v", ref, want)
	}
}

func TestObjectService_CompleteMultipartUpload_XMLSyntaxError(t *testing.T) {
	setup()
	defer teardown()

	eChar, _ := DecodeURIComponent("%07") //特殊字符
	eName := fmt.Sprintf("test/hello_%v.txt", eChar)
	name := "test/hello.txt"
	uploadID := "149795194893578fd83aceef3a88f708f81f00e879fda5ea8a80bf15aba52746d42d512387"

	opt := &CompleteMultipartUploadOptions{
		Parts: []Object{
			{
				PartNumber: 1,
				ETag:       "\"fae3dba15f4d9b2d76cbaed5de3a08e3\"",
			},
			{
				PartNumber: 2,
				ETag:       "\"c81982550f2f965118d486176d9541d4\"",
			},
		},
	}

	mux.HandleFunc("/test/hello.txt", func(w http.ResponseWriter, r *http.Request) {
		v := new(CompleteMultipartUploadOptions)
		xml.NewDecoder(r.Body).Decode(v)

		testMethod(t, r, http.MethodPost)
		vs := values{
			"uploadId": uploadID,
		}
		testFormValues(t, r, vs)

		want := opt
		want.XMLName = xml.Name{Local: "CompleteMultipartUpload"}
		if !reflect.DeepEqual(v, want) {
			t.Errorf("Object.CompleteMultipartUpload request body: %+v, want %+v", v, want)
		}
		fmt.Fprintf(w, `<CompleteMultipartUploadResult>
	<Location>test-1253846586.cos.ap-guangzhou.myqcloud.com/test/hello.txt</Location>
	<Bucket>test-1253846586</Bucket>
	<Key>%v</Key>
	<ETag>&quot;594f98b11c6901c0f0683de1085a6d0e-4&quot;</ETag>
</CompleteMultipartUploadResult>`, eName)
	})

	ref, _, err := client.Object.CompleteMultipartUpload(context.Background(),
		name, uploadID, opt)
	if err != nil {
		t.Fatalf("Object.CompleteMultipartUpload returned error: %v", err)
	}

	want := &CompleteMultipartUploadResult{
		XMLName:  xml.Name{Local: "CompleteMultipartUploadResult"},
		Bucket:   "test-1253846586",
		Key:      eName,
		ETag:     "\"594f98b11c6901c0f0683de1085a6d0e-4\"",
		Location: "test-1253846586.cos.ap-guangzhou.myqcloud.com/test/hello.txt",
	}

	if !reflect.DeepEqual(ref, want) {
		t.Errorf("Object.CompleteMultipartUpload returned \n%#v, want \n%#v", ref, want)
	}
}

func TestObjectService_CompleteMultipartUpload(t *testing.T) {
	setup()
	defer teardown()
	name := "test/hello.txt"
	uploadID := "149795194893578fd83aceef3a88f708f81f00e879fda5ea8a80bf15aba52746d42d512387"

	opt := &CompleteMultipartUploadOptions{
		Parts: []Object{
			{
				PartNumber: 1,
				ETag:       "\"fae3dba15f4d9b2d76cbaed5de3a08e3\"",
			},
			{
				PartNumber: 2,
				ETag:       "\"c81982550f2f965118d486176d9541d4\"",
			},
		},
	}

	mux.HandleFunc("/test/hello.txt", func(w http.ResponseWriter, r *http.Request) {
		v := new(CompleteMultipartUploadOptions)
		xml.NewDecoder(r.Body).Decode(v)

		testMethod(t, r, http.MethodPost)
		vs := values{
			"uploadId": uploadID,
		}
		testFormValues(t, r, vs)

		want := opt
		want.XMLName = xml.Name{Local: "CompleteMultipartUpload"}
		if !reflect.DeepEqual(v, want) {
			t.Errorf("Object.CompleteMultipartUpload request body: %+v, want %+v", v, want)
		}
		fmt.Fprint(w, `<CompleteMultipartUploadResult>
	<Location>test-1253846586.cos.ap-guangzhou.myqcloud.com/test/hello.txt</Location>
	<Bucket>test</Bucket>
	<Key>test/hello.txt</Key>
	<ETag>&quot;594f98b11c6901c0f0683de1085a6d0e-4&quot;</ETag>
</CompleteMultipartUploadResult>`)
	})

	ref, _, err := client.Object.CompleteMultipartUpload(context.Background(),
		name, uploadID, opt)
	if err != nil {
		t.Fatalf("Object.ListParts returned error: %v", err)
	}

	want := &CompleteMultipartUploadResult{
		XMLName:  xml.Name{Local: "CompleteMultipartUploadResult"},
		Bucket:   "test",
		Key:      name,
		ETag:     "\"594f98b11c6901c0f0683de1085a6d0e-4\"",
		Location: "test-1253846586.cos.ap-guangzhou.myqcloud.com/test/hello.txt",
	}

	if !reflect.DeepEqual(ref, want) {
		t.Errorf("Object.CompleteMultipartUpload returned \n%#v, want \n%#v", ref, want)
	}
}

// TestObjectService_CompleteMultipartUpload_EmptyETag_RetrySuccess 模拟服务端 chunk 回包，
// 前两次返回空 ETag（空 body），第三次返回正常结果，验证重试后成功。
func TestObjectService_CompleteMultipartUpload_EmptyETag_RetrySuccess(t *testing.T) {
	setup()
	defer teardown()

	client.Conf.RetryOpt.Count = 3

	name := "test/hello.txt"
	uploadID := "149795194893578fd83aceef3a88f708f81f00e879fda5ea8a80bf15aba52746d42d512387"
	callCount := 0

	mux.HandleFunc("/test/hello.txt", func(w http.ResponseWriter, r *http.Request) {
		testMethod(t, r, http.MethodPost)
		testFormValues(t, r, values{"uploadId": uploadID})
		callCount++
		if callCount < 3 {
			// 前两次：返回 200 但 body 为空（ETag 空）
			fmt.Fprint(w, `<CompleteMultipartUploadResult></CompleteMultipartUploadResult>`)
			return
		}
		// 第三次：返回完整正常结果
		fmt.Fprint(w, `<CompleteMultipartUploadResult>
	<Location>test-1253846586.cos.ap-guangzhou.myqcloud.com/test/hello.txt</Location>
	<Bucket>test</Bucket>
	<Key>test/hello.txt</Key>
	<ETag>&quot;594f98b11c6901c0f0683de1085a6d0e-4&quot;</ETag>
</CompleteMultipartUploadResult>`)
	})

	opt := &CompleteMultipartUploadOptions{
		Parts: []Object{{PartNumber: 1, ETag: `"abc"`}},
	}
	ref, _, err := client.Object.CompleteMultipartUpload(context.Background(), name, uploadID, opt)
	if err != nil {
		t.Fatalf("CompleteMultipartUpload should succeed on retry, got error: %v", err)
	}
	if ref.ETag != `"594f98b11c6901c0f0683de1085a6d0e-4"` {
		t.Errorf("CompleteMultipartUpload ETag = %v, want %v", ref.ETag, `"594f98b11c6901c0f0683de1085a6d0e-4"`)
	}
	if callCount != 3 {
		t.Errorf("expected 3 calls, got %d", callCount)
	}
}

// TestObjectService_CompleteMultipartUpload_EmptyETag_AllRetryFail 模拟所有重试均返回空 ETag，
// 验证最终返回 RetryError 并包含所有错误信息。
func TestObjectService_CompleteMultipartUpload_EmptyETag_AllRetryFail(t *testing.T) {
	setup()
	defer teardown()

	client.Conf.RetryOpt.Count = 3

	name := "test/hello.txt"
	uploadID := "149795194893578fd83aceef3a88f708f81f00e879fda5ea8a80bf15aba52746d42d512387"
	callCount := 0
	errBody := `<CompleteMultipartUploadResult><Location>loc</Location><Bucket>b</Bucket><Key>k</Key></CompleteMultipartUploadResult>`

	mux.HandleFunc("/test/hello.txt", func(w http.ResponseWriter, r *http.Request) {
		testMethod(t, r, http.MethodPost)
		callCount++
		// 每次都返回缺少 ETag 的 body
		fmt.Fprint(w, errBody)
	})

	opt := &CompleteMultipartUploadOptions{
		Parts: []Object{{PartNumber: 1, ETag: `"abc"`}},
	}
	_, _, err := client.Object.CompleteMultipartUpload(context.Background(), name, uploadID, opt)
	if err == nil {
		t.Fatal("expected error, got nil")
	}
	// 必须是 RetryError 类型
	retryErr, ok := err.(*RetryError)
	if !ok {
		t.Fatalf("expected *RetryError, got %T: %v", err, err)
	}
	// RetryOpt.Count=3，每次都失败，应收集到 3 条错误
	if len(retryErr.Errs) != 3 {
		t.Errorf("expected 3 errors in RetryError, got %d: %v", len(retryErr.Errs), retryErr)
	}
	// 每条错误信息应包含 body 内容（字符串形式）
	for i, e := range retryErr.Errs {
		if !strings.Contains(e.Error(), "body contains an error") {
			t.Errorf("error[%d] = %v, want contains 'body contains an error'", i, e)
		}
		if !strings.Contains(e.Error(), "<CompleteMultipartUploadResult>") {
			t.Errorf("error[%d] = %v, want contains XML string body", i, e)
		}
	}
	if callCount != 3 {
		t.Errorf("expected 3 calls, got %d", callCount)
	}
}

// TestObjectService_CompleteMultipartUpload_HTTPError 模拟服务端返回非 200 错误。
func TestObjectService_CompleteMultipartUpload_HTTPError(t *testing.T) {
	setup()
	defer teardown()

	name := "test/hello.txt"
	uploadID := "149795194893578fd83aceef3a88f708f81f00e879fda5ea8a80bf15aba52746d42d512387"

	mux.HandleFunc("/test/hello.txt", func(w http.ResponseWriter, r *http.Request) {
		testMethod(t, r, http.MethodPost)
		w.WriteHeader(http.StatusInternalServerError)
		fmt.Fprint(w, `<Error><Code>InternalError</Code><Message>server error</Message></Error>`)
	})

	opt := &CompleteMultipartUploadOptions{
		Parts: []Object{{PartNumber: 1, ETag: `"abc"`}},
	}
	_, _, err := client.Object.CompleteMultipartUpload(context.Background(), name, uploadID, opt)
	if err == nil {
		t.Fatal("expected error for HTTP 500, got nil")
	}
}

// TestObjectService_CompleteMultipartUpload_200NonXML 覆盖 status=200 但 body 不是合法 XML 的场景。
// COS 规范：合并分块时服务端先返回 200，然后在 body 中流式写入结果；
// 若 body 完全不是 XML（如纯文本、HTML 错误页），需当作错误处理并触发重试。
func TestObjectService_CompleteMultipartUpload_200NonXML(t *testing.T) {
	cases := []struct {
		name        string
		body        string
		// 期望 lastErr.Error() 包含的关键字（按实际 xml 解析行为）
		wantContain string
		// 是否期望 lastErr 是 xml 解析相关错误（非 COS ErrorResponse）
		notCOSError bool
	}{
		{
			// 纯文本：xml.Unmarshal 遇到非 XML 内容抛 SyntaxError，
			// 再经 UnmarshalCompleteMultiUploadResult 仍失败，最终是 EOF
			name:        "plain text body",
			body:        "Internal Server Error",
			wantContain: "",
			notCOSError: true,
		},
		{
			// HTML 页面：xml 根标签是 <html>，不是 SyntaxError 而是解析错误
			name:        "html error page",
			body:        "<html><body>Bad Gateway</body></html>",
			wantContain: "html",
			notCOSError: true,
		},
		{
			// 空 body：xml.Unmarshal 返回 SyntaxError/EOF，
			// UnmarshalCompleteMultiUploadResult 也返回 EOF
			name:        "empty body",
			body:        "",
			wantContain: "",
			notCOSError: true,
		},
		{
			// 200 body 内嵌 XML Error（COS chunk 流式传输的真实错误格式）：
			// xml.Unmarshal 能解析但根元素不是 CompleteMultipartUploadResult，返回解析错误
			name:        "xml error embedded in 200",
			body:        `<?xml version="1.0" encoding="UTF-8"?><Error><Code>InternalError</Code><Message>We encountered an internal error.</Message></Error>`,
			wantContain: "Error",
			notCOSError: true,
		},
		{
			// XML 结构合法但 ETag 为空：触发 "body contains an error" 路径
			name:        "valid xml but empty ETag",
			body:        `<CompleteMultipartUploadResult><Location>loc</Location><Bucket>b</Bucket><Key>k</Key></CompleteMultipartUploadResult>`,
			wantContain: "body contains an error",
			notCOSError: true,
		},
	}

	for _, tc := range cases {
		tc := tc
		t.Run(tc.name, func(t *testing.T) {
			setup()
			defer teardown()

			uploadID := "149795194893578fd83aceef3a88f708f81f00e879fda5ea8a80bf15aba52746d42d512387"
			mux.HandleFunc("/test/hello.txt", func(w http.ResponseWriter, r *http.Request) {
				testMethod(t, r, http.MethodPost)
				w.WriteHeader(http.StatusOK)
				fmt.Fprint(w, tc.body)
			})

			opt := &CompleteMultipartUploadOptions{
				Parts: []Object{{PartNumber: 1, ETag: `"abc"`}},
			}
			_, _, err := client.Object.CompleteMultipartUpload(
				context.Background(), "test/hello.txt", uploadID, opt)
			if err == nil {
				t.Fatal("expected error for 200 non-XML body, got nil")
			}

			// 错误应当被包在 RetryError 里
			retryErr, ok := err.(*RetryError)
			if !ok {
				t.Fatalf("expected *RetryError, got %T: %v", err, err)
			}
			if len(retryErr.Errs) == 0 {
				t.Fatal("RetryError.Errs should not be empty")
			}

			// 以最后一次重试的错误为准
			lastErr := retryErr.Errs[len(retryErr.Errs)-1]
			if tc.wantContain != "" && !strings.Contains(lastErr.Error(), tc.wantContain) {
				t.Errorf("last error = %q, want contains %q", lastErr.Error(), tc.wantContain)
			}

			// 200 非 XML body 不应被误判为 COS 服务端错误（ErrorResponse）
			if tc.notCOSError {
				if _, isCOS := IsCOSError(err); isCOS {
					t.Error("200 non-XML body should not be identified as COS ErrorResponse")
				}
			}
		})
	}
}

func TestObjectService_CopyPart(t *testing.T) {
	setup()
	defer teardown()

	sourceUrl := "test-1253846586.cos.ap-guangzhou.myqcloud.com/test.source"
	opt := &ObjectCopyPartOptions{}
	name := "test/hello.txt"
	uploadID := "xxxxx"
	partNumber := 1

	mux.HandleFunc("/test/hello.txt", func(w http.ResponseWriter, r *http.Request) {
		testMethod(t, r, http.MethodPut)
		vs := values{
			"uploadId":   uploadID,
			"partNumber": "1",
		}
		testFormValues(t, r, vs)
		fmt.Fprint(w, `<Error>
		            <Code>string</Code>
					            <Message>string</Message>
								            <Resource>string</Resource>
											            <RequestId>string</RequestId>
														            <TraceId>string</TraceId>

</Error>`)
	})

	_, _, err := client.Object.CopyPart(context.Background(),
		name, uploadID, partNumber, sourceUrl, opt)
	if err == nil {
		t.Fatalf("Object.CopyPart returned error is nil")
	}
	_, _, err = client.Object.CopyPart(context.Background(),
		name, uploadID, partNumber, "http://"+sourceUrl, opt)
	if err == nil {
		t.Fatalf("Object.CopyPart returned error is nil")
	}
	_, _, err = client.Object.CopyPart(context.Background(),
		name, uploadID, partNumber, "test-1253846586.cos.ap-guangzhou.myqcloud.com", opt)
	if err == nil {
		t.Fatalf("Object.CopyPart returned error is nil")
	}

}

func TestObjectService_MultiCopy(t *testing.T) {
	setup()
	defer teardown()

	totalBytes := 1024 * 1024 * 35
	b := make([]byte, totalBytes)
	rand.Read(b)

	opt := &MultiCopyOptions{
		PartSize:       1,
		ThreadPoolSize: 3,
		useMulti:       true,
		OptCopy: &ObjectCopyOptions{
			&ObjectCopyHeaderOptions{},
			&ACLHeaderOptions{},
		},
	}
	uploadid := "test_uploadid"
	optcom := &CompleteMultipartUploadOptions{}
	for i := 1; i <= 35; i += 1 {
		optcom.Parts = append(optcom.Parts, Object{
			PartNumber: i,
			ETag:       hex.EncodeToString(calMD5Digest(b[(i-1)*1024*1024 : i*1024*1024])),
		})
	}

	mux.HandleFunc("/test.src.copy", func(w http.ResponseWriter, r *http.Request) {
		testMethod(t, r, "HEAD")
		w.Header().Add("Content-Length", strconv.FormatInt(int64(totalBytes), 10))
	})

	mux.HandleFunc("/test.copy", func(w http.ResponseWriter, r *http.Request) {
		r.ParseForm()
		// Upload Part
		if r.Method == http.MethodPut {
			str := r.Form.Get("partNumber")
			partNumber, _ := strconv.ParseInt(str, 10, 64)
			ranger, err := GetRange(r.Header.Get("x-cos-copy-source-range"))
			if err != nil {
				t.Errorf("Object.MultiCopy GetRange failed: %v", err)
			}
			if ranger.Start != (partNumber-1)*1024*1024 || ranger.End != partNumber*1024*1024-1 {
				t.Errorf("Object.MultiCopy range error, range: %+v, partNumber: %+v\n", r.Header.Get("x-cos-copy-source-range"), partNumber)
			}
			if r.Form.Get("uploadId") != uploadid {
				t.Errorf("Object.MultiCopy PartCopy returned %+v, want %+v", r.Form.Get("uploadId"), uploadid)
			}

			fmt.Fprintf(w, `<CopyPartResult>
    <ETag>%v</ETag>
    <LastModified></LastModified>
</CopyPartResult>`, optcom.Parts[partNumber-1].ETag)
			return
		}

		testMethod(t, r, http.MethodPost)
		// Complete MultiPart
		if r.Form.Get("uploadId") == uploadid {
			v := &CompleteMultipartUploadOptions{}
			xml.NewDecoder(r.Body).Decode(v)
			vs := values{
				"uploadId": uploadid,
			}
			testFormValues(t, r, vs)
			want := optcom
			want.XMLName = xml.Name{Local: "CompleteMultipartUpload"}
			if !reflect.DeepEqual(v, want) {
				t.Errorf("Object.MultiCopy Complete request body: %+v, want %+v", v, want)
			}
			fmt.Fprint(w, `<CompleteMultipartUploadResult>
	<Location></Location>
	<Bucket></Bucket>
	<Key></Key>
	<ETag>etag</ETag>
</CompleteMultipartUploadResult>`)
			return
		}

		// Init MultiPart
		fmt.Fprintf(w, `<InitiateMultipartUploadResult>
	<Bucket></Bucket>
	<Key></Key>
	<UploadId>%v</UploadId>
</InitiateMultipartUploadResult>`, uploadid)

	})

	dest := "test.copy"
	soruceURL := fmt.Sprintf("%s/%s", client.BaseURL.BucketURL.Host, "test.src.copy")
	_, _, err := client.Object.MultiCopy(context.Background(), dest, soruceURL, opt)

	if err != nil {
		t.Errorf("Object.MultiCopy failed %v", err)
	}

	soruceURL = fmt.Sprintf("%s/%s?versionId=versionid", client.BaseURL.BucketURL.Host, "test.src.copy")
	_, _, err = client.Object.MultiCopy(context.Background(), dest, soruceURL, opt)
	if err != nil {
		t.Errorf("Object.MultiCopy failed %v", err)
	}

}

func TestObjectService_UploadPartRetry(t *testing.T) {
	setup()
	defer teardown()

	opt := &ObjectUploadPartOptions{
		Listener: &DefaultProgressListener{},
	}
	name := "test/hello.txt"
	data := make([]byte, 1024*1024*3)
	_, err := rand.Read(data)
	tb := crc64.MakeTable(crc64.ECMA)
	realcrc := crc64.Update(0, tb, data)
	uploadID := "xxxxx"
	partNumber := 1

	nr, count := 0, 3
	mux.HandleFunc("/test/hello.txt", func(w http.ResponseWriter, r *http.Request) {
		testMethod(t, r, http.MethodPut)
		vs := values{
			"uploadId":   uploadID,
			"partNumber": "1",
		}
		testFormValues(t, r, vs)

		b, _ := ioutil.ReadAll(r.Body)
		crc := crc64.Update(0, tb, b)
		if !reflect.DeepEqual(crc, realcrc) {
			t.Errorf("Object.Put crc: %v, want: %v", crc, realcrc)
		}
		w.Header().Add("x-cos-hash-crc64ecma", strconv.FormatUint(crc, 10))
		nr++
		if nr < count {
			w.WriteHeader(http.StatusInternalServerError)
		}
	})

	_, err = client.Object.UploadPart(context.Background(), name, uploadID, partNumber, bytes.NewReader(data), opt)
	if err != nil || nr != count {
		t.Errorf("Object.UploadPart failed: %v", err)
	}

	nr, count = 0, 3
	_, err = client.Object.UploadPart(context.Background(), name, uploadID, partNumber, strings.NewReader(string(data)), opt)
	if err != nil || nr != count {
		t.Errorf("Object.UploadPart failed: %v", err)
	}

	// 非io.Seeker不做重试
	nr, count = 0, 3
	_, err = client.Object.UploadPart(context.Background(), name, uploadID, partNumber, bytes.NewBuffer(data), opt)
	if err == nil || nr != 1 {
		t.Errorf("Object.UploadPart failed: %v", err)
	}

	filePath := "tmpfile" + time.Now().Format(time.RFC3339)
	newfile, err := os.Create(filePath)
	if err != nil {
		t.Fatalf("create tmp file failed")
	}
	defer os.Remove(filePath)
	// 源文件内容
	newfile.Write(data)
	newfile.Close()

	fd, err := os.Open(filePath)
	if err != nil {
		t.Fatalf("open file failed: %v", err)
	}
	// 文件关闭, 不做重试
	nr, count = 0, 3
	_, err = client.Object.UploadPart(context.Background(), name, uploadID, partNumber, fd, opt)
	if err == nil || nr != 1 {
		t.Errorf("Object.UploadPart failed: %v", err)
	}
}

// 测试 MultiCopy 所有分块持续失败（耗尽重试）后返回的 error
func TestObjectService_MultiCopyPartFailed(t *testing.T) {
	setup()
	defer teardown()

	totalBytes := 1024 * 1024 * 35

	mux.HandleFunc("/test.src.copyfail", func(w http.ResponseWriter, r *http.Request) {
		testMethod(t, r, "HEAD")
		w.Header().Add("Content-Length", strconv.FormatInt(int64(totalBytes), 10))
	})

	uploadid := "test-multicopy-partfailed-id"
	mux.HandleFunc("/test.dst.copyfail", func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodPut {
			w.WriteHeader(http.StatusInternalServerError)
			return
		}
		if r.Method == http.MethodPost {
			r.ParseForm()
			if r.Form.Get("uploadId") != "" {
				// CompleteMultipartUpload - 不应该到达这里
				w.WriteHeader(http.StatusInternalServerError)
				return
			}
			// InitiateMultipartUpload
			fmt.Fprintf(w, `<InitiateMultipartUploadResult>
	<Bucket></Bucket>
	<Key>test.dst.copyfail</Key>
	<UploadId>%v</UploadId>
</InitiateMultipartUploadResult>`, uploadid)
		}
	})

	opt := &MultiCopyOptions{
		PartSize:       1,
		ThreadPoolSize: 3,
		useMulti:       true,
	}
	dest := "test.dst.copyfail"
	sourceURL := fmt.Sprintf("%s/%s", client.BaseURL.BucketURL.Host, "test.src.copyfail")
	_, _, err := client.Object.MultiCopy(context.Background(), dest, sourceURL, opt)
	if err == nil {
		t.Fatalf("MultiCopy should fail when all parts return 500")
	}
	if !strings.Contains(err.Error(), "failed to get resp content") {
		t.Fatalf("MultiCopy error should contain 'failed to get resp content', got: %v", err)
	}
}
